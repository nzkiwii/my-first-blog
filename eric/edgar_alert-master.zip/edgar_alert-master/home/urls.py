from django.conf.urls import url, include
from django.contrib.auth.views import *
from . import views

urlpatterns = [
    url(r'^$', views.home, name='home'),
    url(r'^logout/$', logout, {'next_page': '/'}),
    url('^', include('django.contrib.auth.urls')),
    url(r'^register/$', views.register, name='register'),
]
