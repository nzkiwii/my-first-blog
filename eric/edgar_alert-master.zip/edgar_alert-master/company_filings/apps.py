from django.apps import AppConfig


class CompanyFilingsConfig(AppConfig):
    name = 'company_filings'
